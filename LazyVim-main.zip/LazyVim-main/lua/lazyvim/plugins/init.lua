require("lazyvim.config").init()

return {}
